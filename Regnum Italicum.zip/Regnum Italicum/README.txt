These are shapefiles for the external boundaries of the Regnum Italicum from the 10th century to 1137, based on the map "Italy from the beginning of the X century to 1137"('Italien vom Anfange des X. Jahrhunderts bis 1137') by Theodor Menke in "Hand-Atlas für die Geschichte des Mittelalters und der neueren Zeit" by Karl von Spruner, newly revised by Theodor Menke (Gotha 1880, p. 72). A .jped file of the map is attached under "Template", the entire atlas is available at: https://gei-digital.gei.de/viewer/!toc/PPN685000710/84/-/

The map was imported into QGis by georeferencing and the boundaries were transferred. When the boundaries follow a coastline, modern coastlines are the basis. The only change concerns the "Isola della Donzella", which was not found on the templates and was therefore disregarded.

The template was in the public domain, I hereby make these shapefiles available under the Attribution-ShareAlike (CC BY-SA) license. This means that reuse and modification is allowed under two conditions: 1. credit to the author (me) and 2. also the result must be made available under this license.

I hope these files help you!

If you do something cool with it, I would be happy about a hint. 

If you want to stay up to date about my work, feel free to follow me on Twitter: https://twitter.com/3mKa1

Last but not least: Get vaccinated or boosted, stay safe and healthy!

Kind regards
Manuel Kamenzin (January 2022)

